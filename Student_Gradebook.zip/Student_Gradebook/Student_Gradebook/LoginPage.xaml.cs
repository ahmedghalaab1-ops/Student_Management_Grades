﻿using Azure.Identity;
using Student_Gradebook.Models;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Student_Gradebook
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Connectionstring connectionstring = new Connectionstring();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;
            if(string.IsNullOrEmpty(username)|| string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter your username or password");
            }
            using (var context = new Connectionstring())
            {
                var user = connectionstring.tbl_Users.FirstOrDefault(u => u.UName == username && u.UPassword == password);
                if (user != null)
                { 
                    if(user.URole == "Teacher")
                    {
                        Teacher teacherpage = new Teacher(user);
                        teacherpage.Show();
                        this.Close();
                    }
                    else if (user.URole == "Student")
                    {
                        Student studentpage = new Student(user);
                        studentpage.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Invalid role assigned to user.");
                    }
                }
                else
                {
                    MessageBox.Show("You have an error in database!!");
                }
            }
        }
    }
}