﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using Microsoft.IdentityModel.Tokens;
using Student_Gradebook.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Student_Gradebook
{
    /// <summary>
    /// Interaction logic for Teacher.xaml
    /// </summary>
    public partial class Teacher : Window
    {
        public Teacher(tbl_Users user)
        {
            InitializeComponent();
            LoadCoursesStudentsData(user.UserID);
        }
        public void LoadCoursesStudentsData(int currentteacherId)
        {
            using (var context = new Connectionstring())
            {
                var SelectedCourse = context.tbl_Courses.Where(u => u.UserID == currentteacherId).ToList();
                cmbGradeType.ItemsSource = SelectedCourse;
            }
        }
        private void cmbGradeType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StudentAssigmentDataGrid.ItemsSource = null;
            txtStudentID.Text = string.Empty;
            txtstudentName.Text = string.Empty;
            txtAVGScore.Text = string.Empty;
            if (cmbGradeType.SelectedItem is Courses selectedCourse)
            {
                using (var context = new Connectionstring())
                {
                    int CSID = selectedCourse.CouresID;
                    var selectedStudents = context.tbl_Enrollment.
                        Include(en => en.tbl_Users)
                        .Where(en => en.CouresID == CSID)
                        .Select(en => new
                        {
                            StudentID = en.tbl_Users.UserID,
                            StudentName = en.tbl_Users.UName,
                            enrollment = en.EnrollmentID
                        })
                        .ToList();

                    StudentAssigmentDataGrid.ItemsSource = selectedStudents;
                }
            }
        }

        private void StudentAssigmentDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            dynamic Selecteditem = StudentAssigmentDataGrid.SelectedItem;
            if (Selecteditem != null)
            {
                txtStudentID.Text = Selecteditem.StudentID.ToString();
                txtstudentName.Text = Selecteditem.StudentName.ToString();
            }
            else
            {
                txtStudentID.Text = string.Empty;
                txtstudentName.Text = string.Empty;
            }
            DGviewScore.ItemsSource = null;
            txtAVGScore.Text = string.Empty;
            txtAssigmentID.Text = string.Empty;
            txtAssigmentName.Text = string.Empty;
            txtGradeID.Text = string.Empty;
            txtScore.Text = string.Empty;
        }
        public void LoadStudentassigment(int enrollmentID)
        {
            using (var context = new Connectionstring())
            {
                var StudentAssigment = context.tbl_Grade.
                    Where(g => g.EnrollmentID == enrollmentID).
                    Select(g => new
                    {
                        AssigmentID = g.GradeID,
                        AssigmentName = g.AssignmentName,
                        Score = g.Score,
                        MaxScore = g.Score
                    }).ToList();
                if (StudentAssigment.Any())
                {
                    DGviewScore.ItemsSource = StudentAssigment;
                    decimal Score = StudentAssigment.Sum(s => s.Score);
                    decimal MaxScore = StudentAssigment.Sum(M => M.MaxScore);
                    if (MaxScore > 0)
                    {
                        decimal AVGpersantage = (MaxScore / Score) * 100;
                        txtAVGScore.Text = AVGpersantage.ToString("F2");
                    }
                    else
                    {
                        DGviewScore.ItemsSource = null;
                        txtAVGScore.Text = string.Empty;
                    }
                }
                
            }
        }

        private void ViewAssigment_Click(object sender, RoutedEventArgs e)
        {
            if (cmbGradeType.SelectedItem == null || string.IsNullOrEmpty(txtStudentID.Text))
            {
                MessageBox.Show("select a course and student");
                return;
            }
            Courses selectedcourse = cmbGradeType.SelectedItem as Courses;
            int courseID = selectedcourse.CouresID;
            int StudentID = int.Parse(txtStudentID.Text);
            using (var context = new Connectionstring())
            {
                var enrollment = context.tbl_Enrollment.FirstOrDefault(e => e.CouresID == courseID && e.UserID == StudentID);
                if (enrollment == null)
                {
                    MessageBox.Show("No Courses and students!!");
                    DGviewScore.ItemsSource = null;
                    return;
                }
                int enrollmentID = enrollment.EnrollmentID;
                LoadStudentassigment(enrollmentID);
            }
        }

        private void DGviewScore_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = DGviewScore.SelectedItem;
            if (selected != null)
            {
                // Use dynamic to access anonymous type properties
                dynamic dynSelected = selected;
                txtAssigmentID.Text = dynSelected.AssigmentID.ToString();
                txtAssigmentName.Text = dynSelected.AssigmentName;
                txtScore.Text = dynSelected.Score.ToString();
            }
            else
            {
                txtAssigmentID.Text = string.Empty;
                txtAssigmentName.Text = string.Empty;
                txtScore.Text = string.Empty;
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            if (cmbGradeType.SelectedItem == null || string.IsNullOrEmpty(txtStudentID.Text))
            {
                MessageBox.Show("select a course and student","Error");
                return;
            }
            string assigmentName = txtAssigmentName.Text;
            string scoreText = txtScore.Text;
            if (string.IsNullOrEmpty(assigmentName)|| string.IsNullOrEmpty(scoreText))
            {
                MessageBox.Show("Enter Assigment Name and score");
                return;
            }
            decimal MaxScore = 100;
            Courses selectedcourse = cmbGradeType.SelectedItem as Courses;
            int courseId = selectedcourse.CouresID;
            int studentid = int.Parse(txtStudentID.Text); // FIX: define studentid from txtStudentID.Text
            using (var context = new Connectionstring())
            {
                var enroolment = context.tbl_Enrollment.FirstOrDefault(E => E.CouresID == courseId && E.UserID == studentid); // FIX: add missing semicolon and use correct variable
                if (enroolment == null)
                {
                    MessageBox.Show("No Courses and students!!");
                    return;
                }
                int enrollmentID = enroolment.EnrollmentID;
                var newGrade = new Grade
                {
                    AssignmentName = assigmentName,
                    Score = decimal.Parse(scoreText),
                    EnrollmentID = enrollmentID,
                    MaxScore = (int)MaxScore,
                };
                context.tbl_Grade.Add(newGrade);
                context.SaveChanges();
                LoadStudentassigment(enrollmentID);
            }

        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtAssigmentID.Text) || string.IsNullOrEmpty(txtAssigmentName.Text) || string.IsNullOrEmpty(txtScore.Text))
            {
                MessageBox.Show("Select an assigment and enter all fields");
                return;
            }
            if (int.TryParse(txtAssigmentID.Text, out int gradeid) || decimal.TryParse(txtScore.Text, out decimal score))
            {
                MessageBox.Show("Invalid Assigment ID or Score");
                return;
            }
            string assigmentName = txtAssigmentName.Text;
            using (var context = new Connectionstring())
            {
                var existingGrade = context.tbl_Grade.FirstOrDefault(g => g.GradeID == gradeid);
                if (existingGrade != null)
                {
                    existingGrade.AssignmentName = assigmentName;
                    existingGrade.Score = score;
                    context.SaveChanges();
                    LoadStudentassigment(existingGrade.EnrollmentID);
                }
                else
                {
                    MessageBox.Show("Assigment not found");
                    return;
                }
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtAssigmentID.Text))
            {
                MessageBox.Show("Select an assigment to delete");
                return;
            }
            if (!int.TryParse(txtAssigmentID.Text, out int assigmentid))
            {
                MessageBox.Show("Invalid Assigment ID");
                return;
            }
            using (var context = new Connectionstring())
            {
                var gradeToDelete = context.tbl_Grade.FirstOrDefault(g => g.GradeID == assigmentid);
                if (gradeToDelete != null)
                {
                    context.tbl_Grade.Remove(gradeToDelete);
                    context.SaveChanges();
                    // Optionally reload assignments for the current enrollment
                    if (cmbGradeType.SelectedItem is Courses selectedCourse && int.TryParse(txtStudentID.Text, out int studentId))
                    {
                        var enrollment = context.tbl_Enrollment.FirstOrDefault(e => e.CouresID == selectedCourse.CouresID && e.UserID == studentId);
                        if (enrollment != null)
                        {
                            LoadStudentassigment(enrollment.EnrollmentID);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Assigment not found");
                }
            }
        }
    }
}
