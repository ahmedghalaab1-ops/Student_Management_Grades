﻿using Microsoft.EntityFrameworkCore;
using Student_Gradebook.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Student_Gradebook
{
    /// <summary>
    /// Interaction logic for Student.xaml
    /// </summary>
    public partial class Student : Window
    {
        private readonly int currentStudentId;
        public Student(tbl_Users users)
        {
            InitializeComponent();
            LoadComboBox(currentStudentId);
        }
        public void LoadComboBox(int studentID)
        {
            using (var context = new Connectionstring())
            {
                var enrolledcourse = context.tbl_Enrollment
                    .Include(e => e.tbl_Courses)
                    .Where(e => e.UserID == currentStudentId)
                    .Select(e => new
                    {
                        e.EnrollmentID,
                        courseName = e.tbl_Courses.CouresName
                    }).ToList();

                StudentsPageCombo.ItemsSource = enrolledcourse;
                StudentsPageCombo.DisplayMemberPath = "courseName";
                StudentsPageCombo.SelectedValuePath = "EnrollmentID";
            }
        }
        public void loadStudentGrades(int enrollmentID)
        {
            using (var context = new Connectionstring())
            {
                var studentsgrade = context.tbl_Grade.
                    Where(e => e.EnrollmentID == enrollmentID).
                    Select(e => new
                    {
                        Assigment = e.AssignmentName,
                        score = e.Score,
                        maxscore = e.MaxScore,
                        percentage = (e.MaxScore > 0) ? (e.Score / e.MaxScore) * 100 : (decimal?)null
                    }).ToList();
                StudentsPageGrid.ItemsSource = studentsgrade;
            }
        }

        private void StudentsPageCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(StudentsPageCombo.SelectedValue is int enrollmentID)
            {
                loadStudentGrades(enrollmentID);
            }
            else
            {
                StudentsPageGrid.ItemsSource = null;
            }
        }
    }
}
