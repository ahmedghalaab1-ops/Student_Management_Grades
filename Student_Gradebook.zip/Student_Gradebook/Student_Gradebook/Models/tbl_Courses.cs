﻿using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Gradebook.Models
{
    public class Courses
    {
        [Key]
        public int CouresID { get; set; }
        public string CouresName { get; set; }
        [ForeignKey(nameof(UserID))]
        tbl_Users tbl_Users { get; set; }
        public int UserID { get; set; }
        public ICollection<Enrollment> Enrollments { get; set; }
    }
}
