﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Gradebook.Models
{
    public class Connectionstring : DbContext
    {
        public DbSet<tbl_Users> tbl_Users { get; set; }
        public DbSet<tbl_Students> tbl_Students { get; set; }
        public DbSet<tbl_Teacher> tbl_Teacher { get; set; }
        public DbSet<Courses> tbl_Courses { get; set; }
        public DbSet<Enrollment> tbl_Enrollment { get; set; }
        public DbSet<Grade> tbl_Grade { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=DESKTOP-N4K0KTP;Initial Catalog=Student_Gradebook;Integrated Security=True;Trust Server Certificate=True");
        }
        override protected void OnModelCreating(ModelBuilder modelBuilder)
        {

        }
    }
}
