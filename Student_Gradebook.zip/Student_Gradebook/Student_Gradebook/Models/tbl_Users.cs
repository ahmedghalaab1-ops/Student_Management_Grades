﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Gradebook.Models
{
    public class tbl_Users
    {
        [Key]
        public int UserID { get; set; }
        public string UName { get; set; }
        public string UPassword { get; set; }
        public string UEmail { get; set; } 
        public string URole { get; set; }
        public ICollection<Enrollment> Enrollments { get; set; }
        public ICollection<Courses> Courses { get; set; }

    }
}
