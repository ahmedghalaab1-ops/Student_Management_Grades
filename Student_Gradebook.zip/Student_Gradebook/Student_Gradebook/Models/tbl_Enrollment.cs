﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Student_Gradebook.Models
{
    public class Enrollment
    {
        [Key]
        public int EnrollmentID { get; set; }
        [ForeignKey(nameof(UserID))]
        public tbl_Users tbl_Users { get; set; }
        public int UserID { get; set; }
        [ForeignKey(nameof(CouresID))]
        public Courses tbl_Courses { get; set; }
        public int CouresID { get; set; }
        public ICollection<Grade> Grades { get; set; }
    }
}
